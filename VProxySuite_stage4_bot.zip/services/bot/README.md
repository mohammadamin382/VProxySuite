# VProxySuite — Bot Service (Stage 4)
Aiogram v3 skeleton wired for future routers and API client.
